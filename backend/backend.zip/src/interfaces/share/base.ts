export interface IBase {
   _id?: string;
   createdAt?: string;
   updatedAt?: string;
}
