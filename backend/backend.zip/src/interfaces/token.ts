export interface IToken {
   userId: string;
   fullName?: string;
   isAdmin?: any;
}
