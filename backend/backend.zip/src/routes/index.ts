import routes from './main.routes';

export { routes };
